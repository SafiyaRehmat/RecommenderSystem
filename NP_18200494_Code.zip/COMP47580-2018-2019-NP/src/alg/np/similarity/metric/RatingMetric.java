/**
 * Compute the similarity between two items based on the Cosine between item ratings
 */ 

package alg.np.similarity.metric;

import profile.Profile;
import util.reader.DatasetReader;

public class RatingMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader

	/**
	 * constructor - creates a new RatingMetric object
	 * @param reader - dataset reader
	 */
	public RatingMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}

	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		// get the movie profiles for movies X and Y		
		Profile movieX = reader.getItemProfiles().get(X);
		Profile movieY = reader.getItemProfiles().get(Y);
		
		// get the normalized mean rating values for both the movies
		// these are the denominator values for the cosine metric 
		double norm_ratings_X =movieX.getNorm();
		double norm_ratings_Y =movieY.getNorm();
		
		// if either value in the denominator is 0, return 0 to prevent division by zero
		if(norm_ratings_X==0 || norm_ratings_Y==0)
			return 0;
		
		// sum stores the numerator value for the cosine metric 
		double sum = 0;
		// iterate over all users who have rated both the movies. We get these ids using the getCommonIds method in Profile
		// for each user, add the product of ratings for both movies to sum
		for( Integer user :movieX.getCommonIds(movieY)) {
			double rating_x = movieX.getValue(user);
			double rating_y = movieY.getValue(user);
			sum +=  rating_x* rating_y;
		}
		// return similarity calculated using Cosine formula
		// we have handled the divide by 0 scenario earlier, line 39 
		return sum/(norm_ratings_X*norm_ratings_Y);
	}
}
