/**
 * Compute the similarity between two items based on the Cosine between item genome scores
 */ 

package alg.np.similarity.metric;

import java.util.Set;

import profile.Profile;
import util.reader.DatasetReader;

public class GenomeMetric implements SimilarityMetric
{
	private DatasetReader reader; // dataset reader
	
	/**
	 * constructor - creates a new GenomeMetric object
	 * @param reader - dataset reader
	 */
	public GenomeMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}
	
	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{
		// get genome scores for movies X and Y
		Profile movieX = reader.getItem(X).getGenomeScores();
		Profile movieY = reader.getItem(Y).getGenomeScores();
		
		// get the normalized mean genome values for both the movies
		// these are the denominator values for the cosine metric 
		double norm_genomescores_X =movieX.getNorm();
		double norm_genomescores_Y =movieY.getNorm();
		
		// if either value in the denominator is 0, return 0 to prevent division by zero
		if(norm_genomescores_X==0 || norm_genomescores_Y==0)
			return 0;
		
		// sum stores the numerator value for the cosine metric 
		double sum = 0;
		// iterate over all tags for which the genome scores are given
		// for each tag, add the product of genome scores for both movies to sum
		for(Integer tag_id : movieX.getIds()){
			double tag_genome_X = movieX.getValue(tag_id);
			double tag_genome_Y = movieY.getValue(tag_id);
			sum +=  tag_genome_X* tag_genome_Y;
		}
		// return similarity calculated using Cosine formula
		// we have handled the divide by 0 scenario earlier, line 42 
		return sum/(norm_genomescores_X*norm_genomescores_Y);
	}
}
