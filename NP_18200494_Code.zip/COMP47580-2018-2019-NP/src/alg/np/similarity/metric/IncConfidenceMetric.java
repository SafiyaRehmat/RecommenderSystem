/**
 * Compute the similarity between two items based on increase in confidence
 */ 

package alg.np.similarity.metric;

import profile.Profile;
import util.reader.DatasetReader;

public class IncConfidenceMetric implements SimilarityMetric
{
	private static double RATING_THRESHOLD = 4.0; // the threshold rating for liked items 
	private DatasetReader reader; // dataset reader
	
	/**
	 * constructor - creates a new IncConfidenceMetric object
	 * @param reader - dataset reader
	 */
	public IncConfidenceMetric(final DatasetReader reader)
	{
		this.reader = reader;
	}
	
	/**
	 * computes the similarity between items
	 * @param X - the id of the first item 
	 * @param Y - the id of the second item
	 */
	public double getItemSimilarity(final Integer X, final Integer Y)
	{		
		//int N =  reader.getUserProfiles().size();
		//not using N to calculate the support as it gets cancelled out once we calculate the confidence
		
		// get movie profiles for movies X and Y
		Profile movieX = reader.getItemProfiles().get(X);
		Profile movieY = reader.getItemProfiles().get(Y);
				
		double sup_X = 0;
		double sup_notX = 0;
		//Get support for X by iterating over all raters and checking who rated X with value >= threshold
		//Get support notX by iterating over all raters and checking who rated X with value < threshold
		for ( int movieXRaters : movieX.getIds()) {
			if(movieX.getValue(movieXRaters)>= RATING_THRESHOLD) {
				sup_X ++;
			}
			if(movieX.getValue(movieXRaters)< RATING_THRESHOLD) {
				sup_notX ++;
			}
		}
				
		double sup_XandY = 0;
		double sup_notXandY = 0;
		// we get raters which rated both the movies using the getCommonIds method in Profile class
		//Get support for X&Y by iterating over all common raters and checking who rated X&Y with values >= threshold
		//Get support for !X&Y by iterating over all common raters and checking who rated X < threshold and Y>= threshold 
		for( Integer user :movieX.getCommonIds(movieY)) {
			if(movieX.getValue(user)>= RATING_THRESHOLD && movieY.getValue(user)>=RATING_THRESHOLD) {
				sup_XandY ++;
			}
			if(reader.getUserProfiles().get(user).getValue(X)< RATING_THRESHOLD && reader.getUserProfiles().get(user).getValue(Y)>=RATING_THRESHOLD) {
				sup_notXandY ++;
			}
		}
		
		//calculate the confidence values for x and !x
		double conf_XandY = sup_X>0 ? sup_XandY/sup_X : 0;
		double conf_notXandY = sup_notX>0 ? sup_notXandY/sup_notX : 0;
		
		// return similarity using conf(X=>Y) / conf(!X => Y)
		return conf_notXandY>0 ? conf_XandY/conf_notXandY : 0;
	}
}
