package alg.ib.predictor;

import java.util.Map;

import alg.ib.neighbourhood.Neighbourhood;
import profile.Profile;
import similarity.SimilarityMap;

public class WeightedAveragePredictor implements Predictor{
	
	/**
	 * constructor - creates a new SimpleAveragePredictor object
	 */
	public WeightedAveragePredictor()
	{
	}
	
	/**
	 * @returns the target user's predicted rating for the target item or null if a prediction cannot be computed
	 * @param userId - the numeric ID of the target user
	 * @param itemId - the numerid ID of the target item
	 * @param userProfileMap - a map containing user profiles
	 * @param itemProfileMap - a map containing item profiles
	 * @param neighbourhood - a Neighbourhood object
	 * @param simMap - a SimilarityMap object containing item-item similarities
	 */
	public Double getPrediction(final Integer userId, final Integer itemId, final Map<Integer,Profile> userProfileMap, final Map<Integer,Profile> itemProfileMap, final Neighbourhood neighbourhood, final SimilarityMap simMap)	
	{
		double numerator = 0;
		double denominator = 0;
		
		for(Integer id: userProfileMap.get(userId).getIds()) // iterate over the target user's items
		{
			if(neighbourhood.isNeighbour(itemId, id)) // check if the current item is in the neighbourhood of target item
			{
				// get the rating given by target user to current item
				double rating = userProfileMap.get(userId).getValue(id);
				// get the item-item similarity between current item and target item
				double sim = simMap.getSimilarity(itemId, id);
				numerator += sim*rating;
				denominator += sim;
			}
		}
		// check for divide by zero error 
		return (denominator != 0) ? numerator / denominator : null;
		
	}

}
