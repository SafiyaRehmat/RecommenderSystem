package alg.ib.predictor;

import java.util.Map;

import alg.ib.neighbourhood.Neighbourhood;
import profile.Profile;
import similarity.SimilarityMap;

public class DeviationFromItemMeanPredictor implements Predictor {
	
	public DeviationFromItemMeanPredictor()
	{
	}
	
	/**
	 * @returns the target user's predicted rating for the target item or null if a prediction cannot be computed
	 * @param userId - the numeric ID of the target user
	 * @param itemId - the numerid ID of the target item
	 * @param userProfileMap - a map containing user profiles
	 * @param itemProfileMap - a map containing item profiles
	 * @param neighbourhood - a Neighbourhood object
	 * @param simMap - a SimilarityMap object containing item-item similarities
	 */
	public Double getPrediction(final Integer userId, final Integer itemId, final Map<Integer,Profile> userProfileMap, final Map<Integer,Profile> itemProfileMap, final Neighbourhood neighbourhood, final SimilarityMap simMap)	
	{
		double numerator = 0;
		double denominator = 0;
		
		// get the mean rating for target item from the item_profile_map
		double mean_rating_for_target_item = itemProfileMap.get(itemId).getMeanValue();
		
		for(Integer id: userProfileMap.get(userId).getIds()) // iterate over the target user's items
		{
			if(neighbourhood.isNeighbour(itemId, id)) // the current item is in the neighbourhood
			{
				//get the rating given by target user to current item
				Double rating = userProfileMap.get(userId).getValue(id);
				// get the mean rating of current item from itemProfileMap
				Double mean_rating_for_similar_item = itemProfileMap.get(id).getMeanValue();
				// get the item-item similarity between current item and target item
				double sim = simMap.getSimilarity(itemId, id);
				
				numerator += sim*(rating.doubleValue()-mean_rating_for_similar_item.doubleValue());
				denominator+= sim;
			}
		}
		// check for divide by zero error and return no prediction if there are no similar items
		return (denominator > 0) ? mean_rating_for_target_item+(numerator / denominator) : null;
		
	}
}
