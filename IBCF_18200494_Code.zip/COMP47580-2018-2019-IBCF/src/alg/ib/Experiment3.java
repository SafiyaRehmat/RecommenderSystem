package alg.ib;

import java.io.File;

import alg.ib.neighbourhood.NearestNeighbourhood;
import alg.ib.neighbourhood.Neighbourhood;
import alg.ib.neighbourhood.ThresholdNeighbourhood;
import alg.ib.predictor.DeviationFromItemMeanPredictor;
import alg.ib.predictor.Predictor;
import similarity.metric.CosineMetric;
import similarity.metric.MeanSquaredDifferenceMetric;
import similarity.metric.PearsonMetric;
import similarity.metric.PearsonSigWeightingMetric;
import similarity.metric.SimilarityMetric;
import util.evaluator.Evaluator;
import util.reader.DatasetReader;

public class Experiment3 {
	
public static void main(String[] args) {
		
		// set the paths and filenames of the item file, genome scores file, train file and test file ...
		String folder = "ml-20m-2018-2019";
		String itemFile = folder + File.separator + "movies-sample.txt";
		String itemGenomeScoresFile = folder + File.separator + "genome-scores-sample.txt";
		String trainFile = folder + File.separator + "train.txt";
		String testFile = folder + File.separator + "test.txt";	
		
		// set the path and filename of the output file ...
		String outputFile = "results" + File.separator + "predictions.txt";
		DatasetReader reader = new DatasetReader(itemFile, itemGenomeScoresFile, trainFile, testFile);
		
		// Create an array containing all metrics that need to be evaluate in Experiment 3 
		SimilarityMetric[] metric_array = { new CosineMetric(), 
											new PearsonMetric(), 
											new PearsonSigWeightingMetric(50), 
											new MeanSquaredDifferenceMetric() };
		for (SimilarityMetric metric : metric_array) 
		{
			// Evaluate predictor wrt each metric individually
			evaluatePredictor(metric, outputFile, reader);	
		}
	}

	/**
	* @param predictor
	* @param neighbourhood
	* @param metric
	* @param outputFile
	* @param reader
	*/
	private static void evaluatePredictor(SimilarityMetric metric, String outputFile, DatasetReader reader) {
	
		System.out.println("Results for "+metric.getClass().getSimpleName());
		Neighbourhood neighbourhood = new NearestNeighbourhood(200);	
		Predictor predictor = new DeviationFromItemMeanPredictor();
		
		ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
		Evaluator eval = new Evaluator(ibcf, reader.getTestData());
		
		// Write to output file
		eval.writeResults(outputFile);
		
		// Display RMSE and coverage
		Double RMSE = eval.getRMSE();
		double coverage = eval.getCoverage();
		if(RMSE != null) System.out.printf("RMSE: %.6f Coverage: %.2f%%\n\n",RMSE,coverage);	
	}

}
