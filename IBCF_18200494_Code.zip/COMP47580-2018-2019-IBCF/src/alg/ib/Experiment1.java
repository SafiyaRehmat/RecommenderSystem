package alg.ib;

import java.io.File;

import alg.ib.neighbourhood.NearestNeighbourhood;
import alg.ib.neighbourhood.Neighbourhood;
import alg.ib.predictor.DeviationFromItemMeanPredictor;
import alg.ib.predictor.NonPersonalisedPredictor;
import alg.ib.predictor.Predictor;
import alg.ib.predictor.SimpleAveragePredictor;
import alg.ib.predictor.WeightedAveragePredictor;
import similarity.metric.CosineMetric;
import similarity.metric.PearsonMetric;
import similarity.metric.SimilarityMetric;
import util.evaluator.Evaluator;
import util.reader.DatasetReader;

public class Experiment1 {

	public static void main(String[] args) {

				// set the paths and filenames of the item file, genome scores file, train file and test file ...
				String folder = "ml-20m-2018-2019";
				String itemFile = folder + File.separator + "movies-sample.txt";
				String itemGenomeScoresFile = folder + File.separator + "genome-scores-sample.txt";
				String trainFile = folder + File.separator + "train.txt";
				String testFile = folder + File.separator + "test.txt";	
				
				// set the path and filename of the output file ...
				String outputFile = "results" + File.separator + "predictions.txt";
				DatasetReader reader = new DatasetReader(itemFile, itemGenomeScoresFile, trainFile, testFile);
				
				// Create an array containing all types of predictors which are needed in Experiment 1 
				Predictor[] predictor_array= {	new NonPersonalisedPredictor(),
												new SimpleAveragePredictor(),
												new WeightedAveragePredictor(),
												new DeviationFromItemMeanPredictor() };
				
				for (Predictor predictor: predictor_array) 
				{	
					System.out.println("Results for "+predictor.getClass().getSimpleName());
					System.out.printf("Neighbourhood:\t RMSE:\t\t Coverage:\n");
					
					// Iterate over all neighbourhood values and evaluate predictor in each case 
					for (int i=10; i<=250 ; i+=10) 
					{
						// Evaluate each predictor for each neighbourhood value individually 
						evaluatePredictor(predictor, i, outputFile, reader);
					}
				}
	}

	/**
	 * @param predictor
	 * @param neighbourhood
	 * @param metric
	 * @param outputFile
	 * @param reader
	 */
	private static void evaluatePredictor(Predictor predictor, int neighbour, String outputFile, DatasetReader reader) {		
			
			Neighbourhood neighbourhood = new NearestNeighbourhood(neighbour);
			SimilarityMetric metric = new CosineMetric();
			
			ItemBasedCF ibcf = new ItemBasedCF(predictor, neighbourhood, metric, reader);
			Evaluator eval = new Evaluator(ibcf, reader.getTestData());
			
			// Write to output file
			eval.writeResults(outputFile);
			
			// Display RMSE and coverage
			Double RMSE = eval.getRMSE();
			double coverage = eval.getCoverage();
			if(RMSE != null) System.out.printf("%d\t\t%.6f\t%.2f%%\n", neighbour, RMSE,coverage);
		
	}

}
