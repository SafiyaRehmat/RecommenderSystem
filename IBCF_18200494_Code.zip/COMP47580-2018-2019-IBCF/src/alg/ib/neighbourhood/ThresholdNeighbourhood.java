package alg.ib.neighbourhood;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

import profile.Profile;
import similarity.SimilarityMap;
import util.ScoredThingDsc;

public class ThresholdNeighbourhood extends Neighbourhood {
	
private final double threshold; // the number of neighbours in the neighbourhood
	
	/**
	 * constructor - creates a new NearestNeighbourhood object
	 * @param k - the number of neighbours in the neighbourhood
	 */
	public ThresholdNeighbourhood(final double threshold)
	{
		super();
		this.threshold = threshold;
	}

	/**
	 * stores the neighbourhoods for all items in member Neighbour.neighbourhoodMap
	 * @param simMap - a map containing item-item similarities
	 */
	public void computeNeighbourhoods(final SimilarityMap simMap)
	{
		for(Integer itemId: simMap.getIds()) // iterate over each item
		{
			Profile profile = simMap.getSimilarities(itemId); // get the item similarity profile
			if(profile != null)
			{
				for(Integer id: profile.getIds()) // iterate over each item in the profile
				{
					// get the item-item similarity
					double sim = profile.getValue(id);
					// if the item-item similarity is greater than threshold, add it to the neighbourhood
					if(sim > threshold)
						this.add(itemId, id);
				}
			}

		}
	}

}
