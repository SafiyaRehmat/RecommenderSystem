package similarity.metric;

import java.util.Set;

import profile.Profile;

public class MeanSquaredDifferenceMetric implements SimilarityMetric{
	
	/**
	 * constructor - creates a new PearsonMetric object
	 */
	public MeanSquaredDifferenceMetric()
	{
	}
		
	/**
	 * computes the similarity between profiles
	 * @param profile 1 
	 * @param profile 2
	 */
	public double getSimilarity(final Profile p1, final Profile p2)
	{
        double sum_r1_r2 = 0;
        double rmin = 0.5, rmax=5;
        // get ids of raters who have rated both the movies 
        Set<Integer> common = p1.getCommonIds(p2);
        // for each common rater, calculate the numerator of the cosine metric
		for(Integer id: common)
		{
			double r1 = p1.getValue(id).doubleValue();
			double r2 = p2.getValue(id).doubleValue();
            sum_r1_r2 += (r1-r2)*(r1-r2);
		}
		
		// setting similarity to zero when there are no common users who have rated both the items. 
		double similarity = (common.size() > 0) ? 1 - sum_r1_r2 / (common.size()*(rmax-rmin)) : 0;
		return similarity ;
	}

}
