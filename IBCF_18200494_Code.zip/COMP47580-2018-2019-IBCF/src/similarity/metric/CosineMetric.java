package similarity.metric;

import java.util.Set;

import profile.Profile;

public class CosineMetric implements SimilarityMetric {
	
	/**
	 * constructor - creates a new PearsonMetric object
	 */
	public CosineMetric()
	{
	}
		
	/**
	 * computes the similarity between profiles
	 * @param profile 1 
	 * @param profile 2
	 */
	public double getSimilarity(final Profile p1, final Profile p2)
	{
        double sum_r1_r2 = 0;
        
        // get ids of raters who have rated both the movies 
        Set<Integer> common = p1.getCommonIds(p2);
        // for each common rater, calculate the numerator of the cosine metric 
		for(Integer id: common)
		{
			double r1 = p1.getValue(id).doubleValue();
			double r2 = p2.getValue(id).doubleValue();
            sum_r1_r2 += r1 * r2;
		}
		// get the denominator values from Profile class 
		double below = p1.getNorm()*p2.getNorm();
		// check for division by zero
		return (below > 0) ? sum_r1_r2 / below : 0;
	}

}
